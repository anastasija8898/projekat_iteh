<?php
include_once('izgled.php');

?>

<?php
	if($red->statuss!="admin"){	
?>
  

<h2 style="color:#666666;"> Dobrodošli u svet šešira. <br> Uživajte u kupovini!</h2>
<br>
<div class="row">


<div class="card text-white bg-secondary mb-5" style="max-width: 50rem; margin-right:22px;">
<div class="card-header"><a href="ponuda.php" style="color:white; text-decoration: none;"><h3>Ponuda</h3></a></div>
  <div class="card-body">
  <a href="ponuda.php"><img src="img/e2.jpg" style="width:230px;height:230px;"/></a>
  </div>
</div>

<div class="card text-white bg-secondary mb-5" style="max-width: 50rem;  margin-right:22px;">
<div class="card-header"><a href="istorijaKupovina.php" style="color:white; text-decoration: none;"><h3>Korpa</h3></a></div>
  <div class="card-body">
  <a href="istorijaKupovina.php"><img src="img/e3.jpg" style="width:230px;height:230px;"/></a>
  </div>
</div>


<div class="card text-white bg-secondary mb-5" style="max-width: 50rem;">
<div class="card-header"><a href="logout.php" style="color:white; text-decoration: none;"><h3>Odjavi se</h3></a></div>
  <div class="card-body">
  <a href="logout.php"><img src="img/e1.jpg" style="width:230px;height:230px;"/></a>
  </div>
</div>
    
	
  </div>	  
<?php
}
else{
include("admin.php");
}
?>

</body>

</html>