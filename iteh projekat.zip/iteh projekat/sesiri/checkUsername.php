<?php
error_reporting(E_ALL | E_STRICT);
ini_set("display_errors", 0);
ini_set("log_errors", 1);
ini_set("error_log", "php_logs.log");
include ("Database.php");
$db=new Database("baza");

if(isset($_POST["korisnickoime"]))
{
	if(!isset($_SERVER['HTTP_X_REQUESTED_WITH']) AND strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
		die();
}
	$username =  strtolower(trim($_POST["korisnickoime"])); 
	
	$username = filter_var($username, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);

	$db->prikaziKorisnika($username);
	$username_exist = mysqli_num_rows($db->getResult());
	if($username_exist) {
		?><b> <?php die('Korisničko ime je zauzeto!');?></b>
	<?php	
	}else{
		?><b><snap style="color:green"><?php die('Korisničko ime je slobodno!');?></snap></b><?php
	}
}
?>