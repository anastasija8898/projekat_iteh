<?php
error_reporting(E_ALL | E_STRICT);
ini_set("display_errors", 0);
ini_set("log_errors", 1);
ini_set("error_log", "php_logs.log");

include_once("izgled.php");
?>

<body>
       
<h1>Dodaj šešir</h1>
<hr>

<div id="dodavanje">
  <form role="form" action="upload.php" method="post" enctype="multipart/form-data">
 
 <div class="form-group">
      <label for="ime">Naziv šešira:</label>
      <input name="ime"type="text" class="form-control" id="ime" placeholder="Unestite naziv šešira" required>
    </div>
    <div class="form-group">
	 <label for="rasa">Kategorija:</label><br>
  <select id="rasaId" name="rasaId" style="width:100%;color:black;padding:10px;"> 
  <?php
  $db->dajRase();
  
      while($red=$db->getResult()->fetch_object()){?>
    <option value='<?php echo $red->rasaId; ?>'>
    <?php echo $red->nazivRase; ?></option>
    <?php
    }
    ?>
</select>

 </div>
 <div class="form-group">
      <label for="ime">Cena šešira:</label>
      <input name="cena"type="text" class="form-control" id="cena" placeholder="Unestite cenu šešira" required>
    </div>

	Fotografija <br>
  <input type="file" name="fileToUpload" id="fileToUpload">
  <br>
  <br>
  <button type="submit" name="submit" class="btn btn-secondary">Dodaj nov šešir</button>

  </form>
</div>

<?php donjiDeo();?>