<?php
include_once("session.php");
include_once('database.php');
$db->prikaziKorisnika($login_session);
$red=$db->getResult()->fetch_object();

gornjiDeo($login_session,$red->statuss);

function gornjiDeo($user,$status){
error_reporting(E_ALL | E_STRICT);
ini_set("display_errors", 0);
ini_set("log_errors", 1);
ini_set("error_log", "php_logs.log");

?>

<!DOCTYPE html>
<head>
<title>E-šešir </title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.16/datatables.min.js"></script>

    <script src="js/jquery-1.11.2.min.js"></script>
<script src="DataTables-1.10.4/media/js/jquery.dataTables.min.js"></script>
<script src="jeditable/jquery.jeditable.js"></script>
<script src="DataTables-1.10.4/extensions/editable/jquery.dataTables.editable.js"></script>

<script type="text/javascript" src="js/dugme.js"></script>
<link rel="stylesheet" href="css/sesiri.css">      

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">E-šeširi </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
<?php 
 if($status!='admin'){?>
  <div class="collapse navbar-collapse" id="navbarColor02">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
      
        <a class="nav-link" href="profil.php" style="color:#c6d9ec">Početna strana</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="ponuda.php" style="color:#c6d9ec">Ponuda</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="istorijaKupovina.php" style="color:#c6d9ec">Korpa</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php" style="color:#c6d9ec">Odjavi se</a>
      </li>
      </ul>
      <span class="nav-item" text-align="right">
        <a class="nav-link" href="profil.php"><?php echo "Ulogovani ste kao ".$user?></a>
      </span>
  </div>
</nav>


<?php
}else{?>
  <div class="collapse navbar-collapse" id="navbarColor02">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
      
        <a class="nav-link" href="profil.php" style="color:#c6d9ec">Početna strana</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="urediPonudu.php" style="color:#c6d9ec">Uredi ponudu</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="dodajSesir.php" style="color:#c6d9ec">Dodaj šešir</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="spisakKupovina.php" style="color:#c6d9ec">Sve kupovine</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="grafik.php" style="color:#c6d9ec">Statistika</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php" style="color:#c6d9ec">Odjavi se</a>
      </li>
      </ul>
      <span class="nav-item" text-align="right">
        <a class="nav-link" href="profil.php"><?php echo "Ulogovani ste kao ".$user?></a>
      </span>
  </div>
</nav>
<?php } ?>
  <br>
   <div class="jumbotron" style="margin-left:170px; margin-right:170px; background-color:rgba(52, 73, 94, 0.2)">
  <div class="container">
   <div class="row">
  
  <div class="col-md-3 col-lg-3"></div>
  <div class="col-md-7 col-lg-7">
  <?php
  
}
function donjiDeo(){
    ?>
</div>
  <div class="col-md-2 col-ld-2"></div>
  </div>
</div>
</div>

</body>

</html>

    <?php
}
  ?>
  