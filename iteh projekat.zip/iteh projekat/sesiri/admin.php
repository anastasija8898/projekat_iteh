
<h2> Dobrodošli na stranicu za administratore </h2>
<br>
<div class="row">



<div class="card text-white bg-secondary mb-5" style="max-width: 50rem; margin-right:22px;">
<div class="card-header"><a href="urediPonudu.php" style="color:white; text-decoration: none;"><h3>Uredi ponudu</h3></a></div>
  <div class="card-body">
  <a href="urediPonudu.php"><img src="img/e5.jpg" style="width:230px;"/></a>
  </div>
</div>

<div class="card text-white bg-secondary mb-5" style="max-width: 50rem;">
<div class="card-header"><a href="dodajSesir.php" style="color:white; text-decoration: none;"><h3>Dodaj šešir</h3></a></div>
  <div class="card-body">
  <a href="dodajSesir.php"><img src="img/e2.jpg" style="width:230px;"/></a>
  </div>
</div>

<div class="card text-white bg-secondary mb-5" style="max-width: 50rem;  margin-right:22px;">
<div class="card-header"><a href="spisakKupovina.php" style="color:white; text-decoration: none;"><h3>Spisak svih <br>kupovina</h3></a></div>
  <div class="card-body">
  <a href="spisakKupovina.php"><img src="img/e3.jpg" style="width:230px;"/></a>
  </div>
</div>

<div class="card text-white bg-secondary mb-5" style="max-width: 50rem;">
<div class="card-header"><a href="grafik.php" style="color:white; text-decoration: none;"><h3>Statistika <br><br></h3></a></div>
  <div class="card-body">
  <a href="grafik.php"><img src="img/e4.jpg" style="width:230px;"/></a>
  </div>
</div>

<div class="card text-white bg-secondary mb-5" style="max-width: 50rem;">
<div class="card-header"><a href="logout.php" style="color:white; text-decoration: none;"><h3>Odjavi se</h3></a></div>
  <div class="card-body">
  <a href="logout.php"><img src="img/e1.jpg" style="width:230px;"/></a>
  </div>
</div>
    
	
  </div>	