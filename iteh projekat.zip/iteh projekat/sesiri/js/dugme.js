window.onscroll = function() {skrolFunkcija()};

function skrolFunkcija() {
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        document.getElementById("dugmence").style.display = "block";
    } else {
        document.getElementById("dugmence").style.display = "none";
    }
}

function vratiNaVrh() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0; 
}