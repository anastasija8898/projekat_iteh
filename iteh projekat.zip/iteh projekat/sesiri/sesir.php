<?php
	  
	   include_once('izgled.php');
	if($red->statuss!="admin"){	


	if(isset($_POST['rezervisi'])){//ako je pritisnuto dugme kupi poziva funkciju web servisa za kupovinu
		$pas=$_GET["pasId"];
	$url = "http://localhost/sesiri/rezervisi";

$data = array(
  'sesir' => $pas,
  'korisnik' => $login_session,
);

$data1=json_encode($data);
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data1);

$json_response = curl_exec($curl);
$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);
$response = json_decode($json_response, true);
$odgovor = $response['poruka'];
echo $odgovor;
		}
		
$url = 'localhost/sesiri/psi/'.$_GET["pasId"].'.json';
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, array('Accept: application/json', 'Content-Type: application/json'));
curl_setopt($curl, CURLOPT_POST, false);

$curl_odgovor = curl_exec($curl);
curl_close($curl);
$jsonobj = json_decode($curl_odgovor);
?>
<div class="card mb-3">
  <h3 class="card-header"><?php echo $jsonobj->psi[0]->ime?></h3>
 
  <img style="height: 100%; width: 100%; display: block;" src="<?php echo $jsonobj->psi[0]->slika; ?>" alt="Slika psa">
  
  <ul class="list-group list-group-flush">
  
    <li class="list-group-item">Kategorija: <?php echo $jsonobj->psi[0]->nazivRase?></li>
  
    <li class="list-group-item">Cena: <?php echo $jsonobj->psi[0]->cena ?> RSD</li>
  </ul>
    <div class="card-footer text-muted">
    <?php 
if ($jsonobj->psi[0]->dostupnost=="da"){
?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

<form method="post" class="forma" style="margin-left:11cm;margin-right:1cm;float: left;">
<input type="submit" class="btn btn-primary" name="rezervisi" value="Kupi!" style="font-size:20px">

<?php
}
else{//ako nema dostupnog šešira
?>	
<legend><h2 style="text-align:center;color:red;">Šešir nije u ponudi trenutno! </h2></legend> 
<?php
}
?>
  </div>
</div>

<?php }
  donjiDeo();
?>
