<?php
//Upravljanje greskama
error_reporting(E_ALL | E_STRICT);
ini_set("display_errors", 0);
ini_set("log_errors", 1);
ini_set("error_log", "php_logs.log");

include('login.php');
if(isset($_SESSION['login_user'])){
header("location: profil.php");
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="css/style.css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<title>E-šešir</title>
</head>
<body>

<div class="container-fluid p-0">
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                 <div class="carousel-item active">
                     <img class="d-block w-100" src="img/pocetna2.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="img/pocetna3.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="img/pocetna4.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="img/pocetna5.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="img/pocetna6.jpg" alt="">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>


<div class="login-box">
<h1 style="color:white"> Ulogujte se </h1>

<form method="post">
<h5 style="color:white">Korisničko ime</h5>
<input type="text" id="korisnickoime" placeholder="Korisničko ime" name="korisnickoime" style="background-color:rgb(255, 255, 255, 0.7);">
<br>
<h5 style="color:white">Šifra</h5>
<input type="password" placeholder="Šifra" name="sifra" style="background-color:rgb(255, 255, 255, 0.7);">
<br><br>
<button type="submit" name="login" value="Uloguj se" class="btn btn-primary">Uloguj se</button>
</form>
<a href="registracija.php" style="color:#00bfff; font-weight: bold;" >Nemate nalog? Registrujte se...</a>
<?php 
if($error=="Pogrešno ste uneli korisničko ime ili sifru!"||$error=="Morate uneti korisničko ime i šifru!"){
echo "<div style='font-size:20px; color:darkred;'>".$error. "</div>";}
?>	

</div><!--login box zatvoren -->
 </body>
</html>