<?php
error_reporting(E_ALL | E_STRICT);
ini_set("display_errors", 0);
ini_set("log_errors", 1);
ini_set("error_log", "php_logs.log");
?>
<html>
<head>
<script src="js/jquery.min.js"></script>
<link href="css/reg.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<script>
//PROVERA DOSTUPNOSTI KORISNICKOG IMENA AJAX
$(document).ready(function() {
	$("#korisnickoime").keyup(function (e) {
	
		//removes spaces from username
		$(this).val($(this).val().replace(/\s/g, ''));
		
		var korisnickoime = $(this).val();
		if(korisnickoime.length < 3){$("#user-result").html('');return;}
		
		if(korisnickoime.length >= 3){
			$.post('checkUsername.php', {'korisnickoime':korisnickoime}, function(data) {
			  $("#user-result").html(data);
			});
		}
	});	
});
</script>
<script>
$(document).ready(function() {
	$("#sifra").keyup(function (e) {
	
		//removes spaces from password
		$(this).val($(this).val().replace(/\s/g, ''));
		
		var sifra = $(this).val();
		if(sifra.length < 5){$("#pass-result").html('<b><span style="color:red">Šifra mora sadržati bar pet karaktera i jedan broj</span></b>');return;}
		else{
			$.post('checkPassword.php', {'sifra':sifra}, function(data) {
			  $("#pass-result").html(data);
			});
		}


		$.get("checkPassword.php", {
                        'sifra': sifra
                    },
                    function(data) {
                        if (data == 0) {
                            
                            $("#pass-result").html('<b><span style="color:red">Uneta šifra mora sadržati bar jedan broj</span></b>');
 
                        }else{
							$("#pass-result").html('<b><span style="color:green">Uneta šifra je dobra</span></b>');
						}
                       
                    });

	});	
});


</script>
<title>Registracija</title>
</head>
<body>

<div class="container-fluid p-0">
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                 <div class="carousel-item active">
                     <img class="d-block w-100" src="img/pocetna2.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="img/pocetna3.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="img/pocetna4.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="img/pocetna5.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="img/pocetna6.jpg" alt="">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>

<div id="registracija">

  <form method="post" >
 <h1 style="color:white"> Registrujte se</h1>
  <h5 style="color:white">Korisničko ime</h5>
 <input type="text" id="korisnickoime" name="korisnickoime"placeholder="Korisničko ime" style="background-color:rgb(255, 255, 255, 0.7);" required>

 <div id="user-result" style="font-size:15px;color:red;"></div>

 <h5 style="color:white">Šifra</h5>
<input type="password"  name="sifra" id="sifra" placeholder="Šifra" style="background-color:rgb(255, 255, 255, 0.7);" required>
<div id="pass-result" style="font-size:15px;color:red;"></div>
<h5 style="color:white">Ime</h5>
 <input type="text" id="ime" name="ime"placeholder="Ime" style="background-color:rgb(255, 255, 255, 0.7);" required>
 <h5 style="color:white">Prezime</h5>
  <input placeholder="Prezime"type="text"  id="prezime"name="prezime" style="background-color:rgb(255, 255, 255, 0.7);" required>

<h5 style="color:white">E-mail</h5>
  <input type="text"  id="email"name="email" placeholder="E-mail" style="background-color:rgb(255, 255, 255, 0.7);" required>

<br><br>
<a href="index.php"><img src="img/back.png" alt="" style="width:30px;height:30px;"></a>
<button type="submit" style=" position: relative;left: 120px;"name="register" class="btn btn-primary">Kreirajte Vaš nalog</button>

<?php if (isset($_POST["register"])){
include ("database.php");
$db=new Database("baza");
$date=date("Y-m-d H:i:s");
$podaci=array($_POST['korisnickoime'],$_POST['sifra'],$_POST['ime'],$_POST['prezime'],$_POST['email'],$date);
if ($db->registracijaKorisnika($podaci)) {
    echo "<div style='font-size:20px; color:green;font-weight: bold;'>Uspešno ste kreirali nalog.</div>";
} else {
	echo "<div style='font-size:20px; color:red; font-weight: bold;'>Neuspešno ste kreirali nalog.</div>";
}
}?>

</form>
</div>

 </body>
</html>