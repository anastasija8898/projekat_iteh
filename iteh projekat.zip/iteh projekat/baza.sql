-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2020 at 12:46 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `baza`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategorije`
--

CREATE TABLE `kategorije` (
  `rasaId` int(18) NOT NULL,
  `nazivRase` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `kategorije`
--

INSERT INTO `kategorije` (`rasaId`, `nazivRase`) VALUES
(1, 'Kape'),
(2, 'Šeširi'),
(3, 'Šubare'),
(4, 'Beretke'),
(5, 'Kačketi');

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE `korisnici` (
  `korisnickoime` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `sifra` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ime` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `prezime` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `datumregistracije` date NOT NULL,
  `statuss` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'korisnik'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`korisnickoime`, `sifra`, `ime`, `prezime`, `email`, `datumregistracije`, `statuss`) VALUES
('Anastasija', '8ab7cec940445e78970274ea950e6824', 'Anastasija', 'Raevskaja', 't@gmail.com', '2020-01-27', NULL),
('Jovana', '82ed31b5c161efae8dfa0493735242b6', 'Jovana', 'Jovic', 'j@gmail.com', '2020-01-30', 'korisnik'),
('Kristina', '164fe98302f6f8cb6d2be1945880c09a', 'Kristina', 'Petrovic', 'kris@gmail.com', '2020-01-31', 'korisnik'),
('Mara', 'b80869c583524382ee4093c09787686e', 'Mara', 'Maric', 'marija@gmail.com', '2020-01-29', 'korisnik'),
('Pera', '95b7bbbec550e0ea9849f1b0c8328351', 'Pera', 'Preric', 'pera@gmail.com', '2020-01-27', 'korisnik'),
('Sara', 'cc5d2424231bee15fcd489c26aa29cd9', 'Sara', 'Saric', 'sara@gmail.com', '2020-02-02', 'korisnik'),
('Stefan', '15eafc83256489114c417957381cccc5', 'Stefan', 'Peric', 'w@gmail.com', '2020-01-29', 'korisnik'),
('Violeta', '244325474477cae91341530d552c5572', 'Violeta', 'Prosevski', 'viki@gmail.com', '2020-01-27', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `korpa`
--

CREATE TABLE `korpa` (
  `rezervacijaId` int(18) NOT NULL,
  `korisnik` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pasId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `korpa`
--

INSERT INTO `korpa` (`rezervacijaId`, `korisnik`, `pasId`) VALUES
(22, 'Anastasija', 11),
(30, 'Jovana', 34),
(34, 'Anastasija', 31),
(36, 'Kristina', 48),
(37, 'Mara', 38),
(38, 'Mara', 37),
(39, 'Mara', 47),
(40, 'Mara', 54),
(41, 'Stefan', 45),
(42, 'Stefan', 46),
(43, 'Pera', 32),
(44, 'Pera', 35),
(45, 'Pera', 40),
(46, 'Pera', 53),
(47, 'Pera', 61),
(49, 'Anastasija', 32),
(50, 'Anastasija', 45),
(51, 'Anastasija', 47),
(53, 'Anastasija', 34),
(54, 'Anastasija', 32);

-- --------------------------------------------------------

--
-- Table structure for table `sesir`
--

CREATE TABLE `sesir` (
  `pasID` int(11) NOT NULL,
  `ime` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rasaId` int(18) NOT NULL,
  `cena` varchar(10) NOT NULL,
  `vlasnik` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `slika` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dostupnost` varchar(2) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'da'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sesir`
--

INSERT INTO `sesir` (`pasID`, `ime`, `rasaId`, `cena`, `vlasnik`, `slika`, `dostupnost`) VALUES
(31, 'AV001', 2, '1790', 'Violeta', 'img/s01.jpg', 'da'),
(32, 'AV002', 2, '1190', 'Violeta', 'img/s02.jpg', 'da'),
(33, 'AV003', 2, '1390', 'Violeta', 'img/s03.jpg', 'da'),
(34, 'AV004', 2, '1390', 'Violeta', 'img/s04.jpg', 'da'),
(35, 'AV005', 2, '1190', 'Violeta', 'img/s05.jpg', 'da'),
(36, 'AV006', 2, '990', 'Violeta', 'img/s06.jpg', 'da'),
(37, 'AV007', 2, '1390', 'Violeta', 'img/s07.jpg', 'da'),
(38, 'AV008', 2, '2790', 'Violeta', 'img/s08.jpg', 'da'),
(39, 'AV009', 2, '2190', 'Violeta', 'img/s09.jpg', 'da'),
(40, 'AV010', 5, '1790', 'Violeta', 'img/s10.jpg', 'da'),
(41, 'AV011', 5, '1190', 'Violeta', 'img/s11.jpg', 'da'),
(42, 'AV012', 5, '1390', 'Violeta', 'img/s12.jpg', 'da'),
(43, 'AV013', 5, '1390', 'Violeta', 'img/s13.jpg', 'da'),
(45, 'AV014', 5, '1590', 'Violeta', 'img/s14.jpg', 'da'),
(46, 'AV015', 4, '1390', 'Violeta', 'img/s15.jpg', 'da'),
(47, 'AV016', 4, '1590', 'Violeta', 'img/s16.jpg', 'da'),
(48, 'AV017', 4, '1390', 'Violeta', 'img/s17.jpg', 'da'),
(49, 'AV018', 1, '1190', 'Violeta', 'img/s18.jpg', 'da'),
(50, 'AV019', 1, '1190', 'Violeta', 'img/s19.jpg', 'da'),
(51, 'AV020', 1, '1190', 'Violeta', 'img/s20.jpg', 'da'),
(52, 'AV021', 1, '1190', 'Violeta', 'img/s21.jpg', 'da'),
(53, 'AV022', 1, '990', 'Violeta', 'img/s22.jpg', 'da'),
(54, 'AV023', 3, '1990', 'Violeta', 'img/s23.jpg', 'da'),
(55, 'AV024', 3, '1990', 'Violeta', 'img/s24.jpg', 'da'),
(56, 'AV025', 3, '1590', 'Violeta', 'img/s25.jpg', 'da'),
(57, 'AV026', 3, '1990', 'Violeta', 'img/s26.jpg', 'da'),
(67, 'AV027', 3, '1990', 'Violeta', 'img/defolt1.jpg', 'da');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategorije`
--
ALTER TABLE `kategorije`
  ADD PRIMARY KEY (`rasaId`);

--
-- Indexes for table `korisnici`
--
ALTER TABLE `korisnici`
  ADD PRIMARY KEY (`korisnickoime`);

--
-- Indexes for table `korpa`
--
ALTER TABLE `korpa`
  ADD PRIMARY KEY (`rezervacijaId`);

--
-- Indexes for table `sesir`
--
ALTER TABLE `sesir`
  ADD PRIMARY KEY (`pasID`),
  ADD KEY `dodao` (`vlasnik`),
  ADD KEY `rasa` (`rasaId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategorije`
--
ALTER TABLE `kategorije`
  MODIFY `rasaId` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `korpa`
--
ALTER TABLE `korpa`
  MODIFY `rezervacijaId` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `sesir`
--
ALTER TABLE `sesir`
  MODIFY `pasID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sesir`
--
ALTER TABLE `sesir`
  ADD CONSTRAINT `dodao` FOREIGN KEY (`vlasnik`) REFERENCES `korisnici` (`korisnickoime`),
  ADD CONSTRAINT `rasa` FOREIGN KEY (`rasaId`) REFERENCES `kategorije` (`rasaId`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
